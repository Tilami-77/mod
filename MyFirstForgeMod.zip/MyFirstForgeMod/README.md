# 🎁 戰利品箱子模組 - Minecraft Forge 1.20.1

一個會在世界各地生成5種稀有度戰利品箱子的Minecraft模組！

## ✨ 功能特色

### 5個稀有度等級
- **普通箱子** 🤍 - 白色粒子，基礎物品
- **罕見箱子** 💚 - 綠色粒子，鐵裝備和金錠
- **稀有箱子** 💙 - 藍色粒子，鑽石裝備
- **史詩箱子** 💜 - 紫色粒子，獄髓錠、三叉戟
- **傳說箱子** 💛 - 金色粒子，獄髓裝備、龍蛋、信標

## 📦 如何構建.jar文件

### 方法1：使用IntelliJ IDEA（推薦）

#### 步驟1：打開項目
1. 啟動IntelliJ IDEA
2. 選擇 **Open**
3. 找到並選擇此文件夾
4. 點擊 **OK**

#### 步驟2：等待Gradle同步
- IDE會自動下載所需依賴（第一次需5-10分鐘）
- 右下角會顯示進度條

#### 步驟3：刷新Gradle
- 點擊IDE右側的 **Gradle** 標籤（大象圖示）
- 點擊左上角的 **🔄 Reload All Gradle Projects**

#### 步驟4：執行build
- 在Gradle視窗中，展開 **MyFirstForgeMod** → **Tasks** → **build**
- **雙擊** `build`
- 等待構建完成（約3-5分鐘）

#### 步驟5：找到jar文件
```
build\libs\myfirstmod-0.0.1-1.20.1.jar
```

### 方法2：使用命令行

如果IntelliJ的Gradle功能正常，也可以在IDE的Terminal中執行：

```powershell
# 在Windows上
.\gradlew build
```

## 🎮 如何安裝模組

### 1. 安裝Forge
- 下載 Forge 1.20.1: https://files.minecraftforge.net/net/minecraftforge/forge/index_1.20.1.html
- 執行安裝程式，選擇 "Install client"

### 2. 複製jar文件到mods文件夾
- 按 `Win + R`，輸入 `%appdata%\.minecraft\mods`
- 將 `myfirstmod-0.0.1-1.20.1.jar` 複製進去

### 3. 啟動遊戲
- 在Minecraft啟動器選擇 **Forge 1.20.1** 配置
- 點擊 **Play**
- 在主選單點擊 **Mods** 查看模組

## 🎯 如何使用

### 在創造模式中測試
1. 打開物品欄（E鍵）
2. 切換到「功能性方塊」標籤
3. 找到5種戰利品箱子
4. 放置並右鍵點擊測試

### 在生存模式中尋找
1. 創建新世界（推薦）
2. 探索世界，尋找發光的箱子
3. 不同顏色粒子代表不同稀有度
4. 右鍵點擊開啟，箱子會消失

## 💎 戰利品內容

### 普通箱子
麵包、蘋果、煤炭、木劍、皮革裝備

### 罕見箱子
鐵錠、金錠、鐵裝備、附魔弓、經驗瓶

### 稀有箱子
鑽石、綠寶石、金蘋果、附魔鑽石裝備、終界珍珠

### 史詩箱子
獄髓錠、附魔金蘋果、高級附魔裝備、三叉戟、鞘翅、不死圖騰

### 傳說箱子
獄髓裝備、鑽石塊、龍蛋、信標、終界之星、不死圖騰

## 🛠️ 開發需求

- Java 17 (JDK)
- IntelliJ IDEA (推薦) 或其他Java IDE
- Minecraft 1.20.1
- Forge 1.20.1 (47.2.0)

## 📝 授權

MIT License - 自由使用和修改

## 🎉 祝你遊戲愉快！
