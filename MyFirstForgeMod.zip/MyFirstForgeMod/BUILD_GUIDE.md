# 📦 構建教學 - 如何打包成.jar文件

## 🎯 目標
將模組打包成 `.jar` 文件，以便可以放入Minecraft的mods文件夾使用。

---

## ✅ 方法1：使用IntelliJ IDEA（最簡單！推薦）

### 第一步：打開項目

1. **啟動IntelliJ IDEA**
2. 點擊 **Open** （不是 New Project）
3. 瀏覽到 `C:\Users\pocke\CascadeProjects\MyFirstForgeMod`
4. 選擇整個文件夾並點擊 **OK**

### 第二步：等待Gradle同步

- IDE會顯示"Gradle Sync"進度
- 右下角有進度條顯示
- **第一次需要5-15分鐘**（下載Forge和Minecraft依賴）
- 請耐心等待，不要中斷

### 第三步：打開Gradle面板

- 點擊IDE **右側邊緣**的 **Gradle** 圖示（大象圖示）
- 或者：點擊 **View** → **Tool Windows** → **Gradle**

### 第四步：刷新Gradle項目

- 在Gradle面板中，點擊左上角的 **🔄 Reload All Gradle Projects** 圖示
- 等待刷新完成

### 第五步：執行build任務

1. 在Gradle面板中，展開 **MyFirstForgeMod**
2. 展開 **Tasks**
3. 展開 **build**
4. **雙擊** `build`
5. 底部的Run窗口會顯示構建進度
6. 等待看到 **BUILD SUCCESSFUL**

### 第六步：找到jar文件

構建成功後，打開文件資源管理器：

```
C:\Users\pocke\CascadeProjects\MyFirstForgeMod\build\libs\myfirstmod-0.0.1-1.20.1.jar
```

**這就是你的模組文件！** 🎉

---

## 🔧 方法2：使用命令行

如果IntelliJ的Gradle功能無問題，也可以使用命令行：

### 在IDE的Terminal中：

1. 點擊IDE底部的 **Terminal** 標籤
2. 輸入以下命令：

```powershell
.\gradlew build
```

3. 按Enter
4. 等待構建完成

---

## 📍 jar文件位置

構建成功後，jar文件會在：

```
項目根目錄\build\libs\myfirstmod-0.0.1-1.20.1.jar
```

完整路徑：
```
C:\Users\pocke\CascadeProjects\MyFirstForgeMod\build\libs\myfirstmod-0.0.1-1.20.1.jar
```

---

## 🎮 如何安裝到Minecraft

### 步驟1：找到mods文件夾

按 `Win + R`，輸入：
```
%appdata%\.minecraft\mods
```
按Enter

如果mods文件夾不存在，手動創建它。

### 步驟2：複製jar文件

將 `myfirstmod-0.0.1-1.20.1.jar` 複製到mods文件夾中

### 步驟3：確認已安裝Forge

- 你需要先安裝 **Forge 1.20.1**
- 下載地址：https://files.minecraftforge.net/net/minecraftforge/forge/index_1.20.1.html
- 下載推薦版本(Recommended)
- 執行安裝程式，選擇 "Install client"

### 步驟4：啟動遊戲

1. 打開Minecraft啟動器
2. 在配置文件下拉選單中選擇 **forge-1.20.1** 
3. 點擊 **Play**
4. 進入遊戲後，在主選單點擊 **Mods** 按鈕
5. 你應該會看到 "戰利品箱子模組"

---

## 🐛 常見問題

### 問題：Gradle同步失敗
**解決方案：**
- 確保已安裝Java 17
- 檢查網路連接是否穩定
- 點擊Gradle面板的刷新按鈕重試

### 問題：找不到Gradle面板
**解決方案：**
- 點擊 View → Tool Windows → Gradle
- 或者在IDE右側邊緣尋找Gradle圖示

### 問題：構建失敗
**解決方案：**
- 查看錯誤信息（紅色文字）
- 確保所有文件都已正確創建
- 嘗試：File → Invalidate Caches → Invalidate and Restart

### 問題：jar文件不存在
**解決方案：**
- 確認構建顯示 BUILD SUCCESSFUL
- 檢查 `build\libs\` 文件夾
- 如果不存在，重新運行build任務

### 問題：遊戲崩潰
**解決方案：**
- 確認Forge版本為1.20.1
- 查看 `logs\latest.log` 文件
- 確認jar文件完整（應該有幾百KB大小）

---

## 💡 提示

1. **第一次構建會很慢** - 需要下載很多依賴項，這是正常的
2. **使用SSD** - 如果可能，將項目放在SSD上會更快
3. **不要中斷構建** - 讓它完整運行完畢
4. **網路連接** - 構建需要從網路下載文件，確保連接穩定

---

## ✅ 成功的標誌

當你看到以下信息時，表示構建成功：

```
BUILD SUCCESSFUL in XXs
```

然後你就可以在 `build\libs\` 文件夾找到你的jar文件！

---

**祝構建順利！** 🚀

如果遇到任何問題，請檢查：
1. Java 17是否正確安裝
2. 網路連接是否正常
3. 是否使用的是IntelliJ IDEA的最新版本
