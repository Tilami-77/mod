package com.yourname.myfirstmod.block;

import com.yourname.myfirstmod.MyFirstMod;
import com.yourname.myfirstmod.item.ModItems;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, MyFirstMod.MOD_ID);

    public static final RegistryObject<Block> COMMON_LOOT_CHEST = registerBlock("common_loot_chest",
            () -> new LootChestBlock(BlockBehaviour.Properties.copy(Blocks.BARREL), LootChestBlock.LootTier.COMMON));

    public static final RegistryObject<Block> UNCOMMON_LOOT_CHEST = registerBlock("uncommon_loot_chest",
            () -> new LootChestBlock(BlockBehaviour.Properties.copy(Blocks.BARREL), LootChestBlock.LootTier.UNCOMMON));

    public static final RegistryObject<Block> RARE_LOOT_CHEST = registerBlock("rare_loot_chest",
            () -> new LootChestBlock(BlockBehaviour.Properties.copy(Blocks.BARREL), LootChestBlock.LootTier.RARE));

    public static final RegistryObject<Block> EPIC_LOOT_CHEST = registerBlock("epic_loot_chest",
            () -> new LootChestBlock(BlockBehaviour.Properties.copy(Blocks.BARREL), LootChestBlock.LootTier.EPIC));

    public static final RegistryObject<Block> LEGENDARY_LOOT_CHEST = registerBlock("legendary_loot_chest",
            () -> new LootChestBlock(BlockBehaviour.Properties.copy(Blocks.BARREL), LootChestBlock.LootTier.LEGENDARY));

    private static <T extends Block> RegistryObject<T> registerBlock(String name, java.util.function.Supplier<T> block) {
        RegistryObject<T> toReturn = BLOCKS.register(name, block);
        registerBlockItem(name, toReturn);
        return toReturn;
    }

    private static <T extends Block> void registerBlockItem(String name, RegistryObject<T> block) {
        ModItems.ITEMS.register(name, () -> new BlockItem(block.get(), new Item.Properties()));
    }

    public static void register(IEventBus eventBus) {
        BLOCKS.register(eventBus);
    }
}
