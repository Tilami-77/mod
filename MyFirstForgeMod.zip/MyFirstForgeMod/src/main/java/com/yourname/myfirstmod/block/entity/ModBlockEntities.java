package com.yourname.myfirstmod.block.entity;

import com.yourname.myfirstmod.MyFirstMod;
import com.yourname.myfirstmod.block.ModBlocks;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModBlockEntities {
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, MyFirstMod.MOD_ID);

    public static final RegistryObject<BlockEntityType<LootChestBlockEntity>> LOOT_CHEST_BLOCK_ENTITY =
            BLOCK_ENTITIES.register("loot_chest_block_entity", () ->
                    BlockEntityType.Builder.of(LootChestBlockEntity::new,
                            ModBlocks.COMMON_LOOT_CHEST.get(),
                            ModBlocks.UNCOMMON_LOOT_CHEST.get(),
                            ModBlocks.RARE_LOOT_CHEST.get(),
                            ModBlocks.EPIC_LOOT_CHEST.get(),
                            ModBlocks.LEGENDARY_LOOT_CHEST.get()
                    ).build(null));

    public static void register(IEventBus eventBus) {
        BLOCK_ENTITIES.register(eventBus);
    }
}
