package com.yourname.myfirstmod.block.entity;

import com.yourname.myfirstmod.MyFirstMod;
import com.yourname.myfirstmod.block.LootChestBlock;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.loot.LootParams;
import net.minecraft.world.level.storage.loot.LootTable;
import net.minecraft.world.level.storage.loot.parameters.LootContextParamSets;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;
import net.minecraft.world.phys.Vec3;

public class LootChestBlockEntity extends BlockEntity {
    
    public LootChestBlockEntity(BlockPos pos, BlockState blockState) {
        super(ModBlockEntities.LOOT_CHEST_BLOCK_ENTITY.get(), pos, blockState);
    }

    public static void tick(Level level, BlockPos pos, BlockState state, LootChestBlockEntity blockEntity) {
        if (level.isClientSide() && level.getRandom().nextInt(10) == 0) {
            if (state.getBlock() instanceof LootChestBlock lootChest) {
                spawnParticles(level, pos, lootChest.getTier());
            }
        }
    }

    private static void spawnParticles(Level level, BlockPos pos, LootChestBlock.LootTier tier) {
        double x = pos.getX() + 0.5;
        double y = pos.getY() + 1.2;
        double z = pos.getZ() + 0.5;

        double offsetX = (level.random.nextDouble() - 0.5) * 1.0;
        double offsetZ = (level.random.nextDouble() - 0.5) * 1.0;

        switch (tier) {
            case COMMON -> {
                // 白色
                level.addParticle(ParticleTypes.END_ROD, x + offsetX, y, z + offsetZ, 0, 0.05, 0);
            }
            case UNCOMMON -> {
                // 绿色
                level.addParticle(ParticleTypes.HAPPY_VILLAGER, x + offsetX, y, z + offsetZ, 0, 0.05, 0);
            }
            case RARE -> {
                // 蓝色
                level.addParticle(ParticleTypes.SOUL_FIRE_FLAME, x + offsetX, y, z + offsetZ, 0, 0.05, 0);
            }
            case EPIC -> {
                // 紫色
                level.addParticle(ParticleTypes.PORTAL, x + offsetX, y, z + offsetZ, 0, 0.05, 0);
            }
            case LEGENDARY -> {
                // 金色
                level.addParticle(ParticleTypes.TOTEM_OF_UNDYING, x + offsetX, y, z + offsetZ, 0, 0.05, 0);
            }
        }
    }

    public void grantLootAndRemove(Player player, ServerLevel level, BlockPos pos) {
        if (level.getBlockState(pos).getBlock() instanceof LootChestBlock lootChest) {
            ResourceLocation lootTableLocation = new ResourceLocation(MyFirstMod.MOD_ID,
                    "chests/" + lootChest.getTier().getName() + "_loot_chest");

            LootTable lootTable = level.getServer().getLootData().getLootTable(lootTableLocation);

            LootParams lootParams = new LootParams.Builder(level)
                    .withParameter(LootContextParams.ORIGIN, Vec3.atCenterOf(pos))
                    .withParameter(LootContextParams.THIS_ENTITY, player)
                    .create(LootContextParamSets.CHEST);

            lootTable.getRandomItems(lootParams).forEach(itemStack -> {
                if (!player.getInventory().add(itemStack)) {
                    player.drop(itemStack, false);
                }
            });

            // 播放拾取物品音效
            level.playSound(null, pos, SoundEvents.ITEM_PICKUP, SoundSource.BLOCKS, 1.0F, 1.0F);

            // 柔和的末地烛粒子效果
            for (int i = 0; i < 30; i++) {
                double offsetX = (level.random.nextDouble() - 0.5) * 0.5;
                double offsetY = level.random.nextDouble() * 0.8;
                double offsetZ = (level.random.nextDouble() - 0.5) * 0.5;
                level.sendParticles(ParticleTypes.END_ROD,
                        pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5,
                        1, offsetX, offsetY, offsetZ, 0.05);
            }

            level.setBlock(pos, Blocks.AIR.defaultBlockState(), 3);
        }
    }
}
